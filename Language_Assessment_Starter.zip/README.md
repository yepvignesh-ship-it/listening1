# Language Assessment Platform

This starter package contains a basic HTML landing page.

The complete production system (authentication, recording,
AI scoring, database, admin dashboard, etc.) must be developed
as a multi-file web application.
